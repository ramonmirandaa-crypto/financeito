export default function Home() {
  return (
    <div className="text-center mt-24">
      <h1 className="text-5xl font-bold mb-4">Financeito</h1>
      <p className="opacity-80">Seu centro de finanças pessoais com Open Finance.</p>
    </div>
  )
}
